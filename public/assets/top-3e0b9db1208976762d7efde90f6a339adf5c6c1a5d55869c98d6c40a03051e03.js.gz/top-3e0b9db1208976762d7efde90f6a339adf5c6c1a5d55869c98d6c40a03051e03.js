$('#search-pre-btn').on('click',function(){
    $('#search-pre-btn').hide();
    $('#search-box').show();
});
